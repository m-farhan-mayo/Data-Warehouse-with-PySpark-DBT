WITH dedup_query AS
(
SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY id ORDER BY updatedate DESC) as dedup
FROM
    {{ source('source', 'items4scd') }}
)
SELECT
    id,
    name,
    category,
    updatedate
FROM
    dedup_query
WHERE
    dedup = 1