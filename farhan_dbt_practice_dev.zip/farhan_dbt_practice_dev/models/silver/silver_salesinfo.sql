WITH bronze_sales AS (
    SELECT
        sales_id,
        product_sk,
        customer_sk,
        unit_price, 
        quantity,    
        {{ multiply('unit_price','quantity') }} AS calculated_gross_amount,
        gross_amount,
        payment_method
    FROM
        {{ ref("bronze_sales") }}
),

bronze_product AS (
    SELECT
        product_sk,
        category
    FROM
        {{ ref("bronze_product") }}
),

bronze_customer AS (
    SELECT
        customer_sk,
        gender
    FROM
        {{ ref("bronze_customer") }}
),

join_query AS(
SELECT
    sales.sales_id,
    sales.gross_amount,
    sales.payment_method,
    products.category,
    customer.gender
FROM
    -- Use the defined CTE name and alias it as 'sales'
    bronze_sales sales
INNER JOIN
    bronze_product products ON sales.product_sk = products.product_sk
INNER JOIN
    bronze_customer customer ON sales.customer_sk = customer.customer_sk
)

SELECT
    category,
    gender,
    sum(gross_amount) as total_sales
FROM
    join_query
GROUP BY
    category,
    gender
ORDER BY
    total_sales DESC