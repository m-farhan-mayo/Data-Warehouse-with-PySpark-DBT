SELECT 
    * 
FROM 
   {{ ref('fact_sales') }}
WHERE
    gross_amount < 0 net_amount < 0