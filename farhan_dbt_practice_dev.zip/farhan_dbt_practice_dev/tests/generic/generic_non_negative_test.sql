{% test generic_non_negative_test(model,column)%}

SELECT
    *
FROM
    {{ model }}
WHERE
    {{ column }} < 0
    
{% endtest %}