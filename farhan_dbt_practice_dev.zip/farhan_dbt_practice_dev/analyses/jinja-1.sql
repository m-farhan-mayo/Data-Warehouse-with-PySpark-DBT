{% set var_name = 'Farhan MaYo'%}

{{ var_name}}