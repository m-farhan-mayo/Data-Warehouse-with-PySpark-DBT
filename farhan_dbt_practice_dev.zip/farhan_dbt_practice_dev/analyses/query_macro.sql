SELECT 
  {{ multiply(10, 12) }} as test_col