{% set Fruits =["Apple", "Mango", "Grapes" ,"Banana"] %}

{% for i in Fruits%}

    {% if i != "Apple"%}
        {{i}}
    {% else %}
        I Dont Like {{i}}
    {% endif%}
    
{% endfor %}