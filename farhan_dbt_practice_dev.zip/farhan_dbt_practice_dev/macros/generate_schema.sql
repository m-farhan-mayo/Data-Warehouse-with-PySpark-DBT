{% macro generate_schema_name(custom_Schema_name, node) -%}

    {%- set default_schema = target.schema -%} 
    
    {%- if custom_Schema_name is none -%}  {# CHANGED to match definition #}

        {{ default_schema }}

    {%- else -%}

        {{ custom_Schema_name | trim }}
        
    {%- endif -%}

{%- endmacro %}